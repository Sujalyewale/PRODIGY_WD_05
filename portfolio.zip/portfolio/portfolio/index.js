// Toggle Menu Icon for Responsive Navbar
const menuIcon = document.getElementById('menu-icon');
const navbar = document.querySelector('.navbar');

menuIcon.addEventListener('click', () => {
    navbar.classList.toggle('active');
});

// Close Navbar on Link Click (for mobile view)
const navLinks = document.querySelectorAll('.navbar a');

navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navbar.classList.remove('active');
    });
});

// Smooth Scrolling for Navigation Links
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href').substring(1);
        const targetSection = document.getElementById(targetId);

        window.scrollTo({
            top: targetSection.offsetTop - 50, // Adjust scroll offset for fixed header
            behavior: 'smooth'
        });
    });
});

// Contact Form Validation
const contactForm = document.querySelector('.contact form');

contactForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const messageInput = document.getElementById('message');

    if (validateForm(nameInput, emailInput, phoneInput, messageInput)) {
        alert('Message sent successfully!');
        contactForm.reset();
    }
});

function validateForm(name, email, phone, message) {
    if (name.value.trim() === '') {
        alert('Please enter your name.');
        return false;
    }

    if (email.value.trim() === '' || !validateEmail(email.value)) {
        alert('Please enter a valid email address.');
        return false;
    }

    if (phone.value.trim() === '' || !validatePhone(phone.value)) {
        alert('Please enter a valid phone number.');
        return false;
    }

    if (message.value.trim() === '') {
        alert('Please enter a message.');
        return false;
    }

    return true;
}

function validateEmail(email) {
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailPattern.test(email);
}

function validatePhone(phone) {
    const phonePattern = /^[0-9]{10}$/;
    return phonePattern.test(phone);
}
